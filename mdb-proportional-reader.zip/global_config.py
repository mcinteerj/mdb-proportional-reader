#!/usr/bin/env python3
mongo_uri = "mongodb+srv://xxx:yyy@cluster1.zo2rl.gcp.mongodb.net/test?retryWrites=true&w=majority"
#mongo_uri = "mongodb://localhost:27017"
dbname = "testdb"
collname = "testcoll"