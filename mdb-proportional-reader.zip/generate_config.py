#!/usr/bin/env python3
docsToGenerate = 112
#docsToGenerate = 100000
maxGenerateChunkSize = 10000
processes = 3
reportingIntervalSeconds = 1