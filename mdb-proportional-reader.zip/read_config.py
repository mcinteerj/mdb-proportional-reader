#!/usr/bin/env python3
procsRatio = [2,1]
docsRatio = [1,100000]
readDurationSeconds = 60
intervalResultReportingSeconds = 5
threadsPerProc = 8